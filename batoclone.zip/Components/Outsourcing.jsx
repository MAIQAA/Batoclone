import React from "react";

const Outsourcing = () => {
  return (
    <div className="relative grid justify-center text-white xl:py-40 md:py-32 py-28 lg:px-16 md:px-10 px-5 space-y-10"></div>
  );
};

export default Outsourcing;
